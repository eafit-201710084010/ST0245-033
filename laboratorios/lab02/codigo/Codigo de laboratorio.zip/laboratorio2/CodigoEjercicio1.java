import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.Arrays;

public class CodigoEjercicio1{
    
    public static void ArraySum (int  [] Sum){
	int c = 0;
	for (int i = 0; i<Sum.length; i++) 
	    {
		c = c + Sum[i];  
		try{
		    TimeUnit.MILLISECONDS.sleep(1);
		} catch (Exception e){
            
		}
	    }
	System.out.println ("ARRAY SUM: " + c);
    }

    public static void ArrayMax(int[] A){
	int max = A[0];
	for (int i = 0; i < A.length; i++){
	    if (A[i] > max){
		max = A[i];
	    }
	}
	try{
	    TimeUnit.MILLISECONDS.sleep(1);
	}
	catch(Exception e){}
	System.out.println("ARRAY MAX: " + max);
    }

    public static void insertionSort(int[] array){
	for(int i= 0; i<array.length; ++i){
	    int min = array[i];
	    for(int j=0; j<array.length; ++j){
		if(array[j] > min){
		    min = array[j];
		    int temp = array[i];
		    array[i] = array[j];
		    array[j] = temp;
		}
	    }
	    try{
		TimeUnit.MILLISECONDS.sleep(1);
	    }
	    catch(Exception e){}
	}
	System.out.println("INSERTION SORT: " +  Arrays.toString(array));
    }

    public static void mergeSort(int[] array){
	int[] tmp = new int[array.length];
	mergeSort(array, tmp, 0, array.length-1);
	try{
	    TimeUnit.MILLISECONDS.sleep(1);
	}
	catch(Exception e){}
	System.out.println("MERGE SORT: " + Arrays.toString(array));
    }
    private static void mergeSort(int[] array, int[] tmp, int left, int right){
	if(left < right){
	    int center = (left + right)/2;
	    mergeSort(array, tmp, left, center);
	    mergeSort(array, tmp, center+1, right);
	    merge(array, tmp, left, center+1, right);
	}
    }
    private static void merge(int[]array, int[]tmp, int left, int right, int rightEnd){
	int leftEnd = right-1;
	int k = left;
	int num = rightEnd - left+1;
	
	while(left <= leftEnd && right <= rightEnd){
	    if(array[left] <= array[right]){
		tmp[k++] = array[left++];
	    }
	    else{
		tmp[k++] = array[right++];
	    }
	}
	while(left <= leftEnd){
	    tmp[k++] = array[left++];
	}
	while(right <= rightEnd){
	    tmp[k++] = array[right++];
	}
	for(int i=0; i<num; i++, rightEnd--){
	    array[rightEnd] = tmp[rightEnd];
	}
    }

    public static int[] generarArregloDeTamanoN(int n){
	int max = 5000;
	int[] array = new int[n];
	Random generator = new Random();
	for(int i=0; i<n; ++i){
	    array[i] = generator.nextInt(max);
	}
	return array;
    }

    public static long tomarTiempo(int n){
	int[] a = generarArregloDeTamanoN(n);
	long startTime1 = System.currentTimeMillis();
	ArraySum(a);
	long estimatedTime1 = System.currentTimeMillis() - startTime1;
	System.out.println("TIEMPO: " + estimatedTime1);

	long startTime2 = System.currentTimeMillis();
	ArrayMax(a);
	long estimatedTime2 = System.currentTimeMillis() - startTime2;
	System.out.println("TIEMPO: " + estimatedTime2);  
	
	long startTime3 = System.currentTimeMillis();
	insertionSort(a);
	long estimatedTime3 = System.currentTimeMillis() - startTime3; 
	System.out.println("TIEMPO: " + estimatedTime3);  
	
	long startTime4 = System.currentTimeMillis();
	mergeSort(a);
	long estimatedTime4 = System.currentTimeMillis() - startTime4;
        System.out.println("TIEMPO: " + estimatedTime4);

    long estimatedTime = estimatedTime1 + estimatedTime2 + estimatedTime3 + estimatedTime4;
	return estimatedTime;
    }

    public static void main(String[] args){
	System.out.println("TIEMPO TOTAL:: " + tomarTiempo(10000));
    }
}